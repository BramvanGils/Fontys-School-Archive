﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2D_Game
{
    class Weapon
    {
        enum Type {bom ,vuurwapen, korteafstandswapen};
        public int Aanvalspunten = 15;
    }
}
