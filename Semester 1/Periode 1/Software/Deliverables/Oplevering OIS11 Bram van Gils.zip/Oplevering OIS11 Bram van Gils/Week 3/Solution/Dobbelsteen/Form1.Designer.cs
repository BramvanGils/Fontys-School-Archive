﻿namespace Dobbelsteen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Picture1 = new System.Windows.Forms.PictureBox();
            this.Picture6 = new System.Windows.Forms.PictureBox();
            this.Picture5 = new System.Windows.Forms.PictureBox();
            this.Picture4 = new System.Windows.Forms.PictureBox();
            this.Picture3 = new System.Windows.Forms.PictureBox();
            this.Picture2 = new System.Windows.Forms.PictureBox();
            this.Button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Picture1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture2)).BeginInit();
            this.SuspendLayout();
            // 
            // Picture1
            // 
            this.Picture1.Image = ((System.Drawing.Image)(resources.GetObject("Picture1.Image")));
            this.Picture1.Location = new System.Drawing.Point(0, 0);
            this.Picture1.Name = "Picture1";
            this.Picture1.Size = new System.Drawing.Size(114, 114);
            this.Picture1.TabIndex = 0;
            this.Picture1.TabStop = false;
            // 
            // Picture6
            // 
            this.Picture6.Image = ((System.Drawing.Image)(resources.GetObject("Picture6.Image")));
            this.Picture6.Location = new System.Drawing.Point(0, 0);
            this.Picture6.Name = "Picture6";
            this.Picture6.Size = new System.Drawing.Size(114, 114);
            this.Picture6.TabIndex = 1;
            this.Picture6.TabStop = false;
            // 
            // Picture5
            // 
            this.Picture5.Image = ((System.Drawing.Image)(resources.GetObject("Picture5.Image")));
            this.Picture5.Location = new System.Drawing.Point(0, 0);
            this.Picture5.Name = "Picture5";
            this.Picture5.Size = new System.Drawing.Size(114, 114);
            this.Picture5.TabIndex = 2;
            this.Picture5.TabStop = false;
            // 
            // Picture4
            // 
            this.Picture4.Image = ((System.Drawing.Image)(resources.GetObject("Picture4.Image")));
            this.Picture4.Location = new System.Drawing.Point(0, 0);
            this.Picture4.Name = "Picture4";
            this.Picture4.Size = new System.Drawing.Size(114, 114);
            this.Picture4.TabIndex = 3;
            this.Picture4.TabStop = false;
            // 
            // Picture3
            // 
            this.Picture3.Image = ((System.Drawing.Image)(resources.GetObject("Picture3.Image")));
            this.Picture3.Location = new System.Drawing.Point(0, 0);
            this.Picture3.Name = "Picture3";
            this.Picture3.Size = new System.Drawing.Size(114, 114);
            this.Picture3.TabIndex = 4;
            this.Picture3.TabStop = false;
            // 
            // Picture2
            // 
            this.Picture2.Image = ((System.Drawing.Image)(resources.GetObject("Picture2.Image")));
            this.Picture2.Location = new System.Drawing.Point(0, 0);
            this.Picture2.Name = "Picture2";
            this.Picture2.Size = new System.Drawing.Size(114, 114);
            this.Picture2.TabIndex = 5;
            this.Picture2.TabStop = false;
            this.Picture2.Click += new System.EventHandler(this.Picture2_Click);
            // 
            // Button
            // 
            this.Button.Location = new System.Drawing.Point(21, 120);
            this.Button.Name = "Button";
            this.Button.Size = new System.Drawing.Size(75, 23);
            this.Button.TabIndex = 6;
            this.Button.Text = "Roll";
            this.Button.UseVisualStyleBackColor = true;
            this.Button.Click += new System.EventHandler(this.Button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(120, 146);
            this.Controls.Add(this.Button);
            this.Controls.Add(this.Picture2);
            this.Controls.Add(this.Picture3);
            this.Controls.Add(this.Picture4);
            this.Controls.Add(this.Picture5);
            this.Controls.Add(this.Picture6);
            this.Controls.Add(this.Picture1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Picture1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Picture1;
        private System.Windows.Forms.PictureBox Picture6;
        private System.Windows.Forms.PictureBox Picture5;
        private System.Windows.Forms.PictureBox Picture4;
        private System.Windows.Forms.PictureBox Picture3;
        private System.Windows.Forms.PictureBox Picture2;
        private System.Windows.Forms.Button Button;
    }
}

